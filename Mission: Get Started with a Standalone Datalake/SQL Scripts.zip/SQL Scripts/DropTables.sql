/*==============================================================*/
/* DBMS name:      Data Lake                                    */
/* Created on:     xx/xx/20xx                                   */
/*==============================================================*/
/*==============================================================*/
/* User: TPCH                                                   */
/*==============================================================*/
/* Tables:                                          */
/*==============================================================*/
drop table TPCH.SUPPLIER;
drop table TPCH.CUSTOMER;
drop table TPCH.NATION;
drop table TPCH.REGION;

/* Drop User, uncomment following line to drop user as well */
/* DROP USER TPCH;                                         */
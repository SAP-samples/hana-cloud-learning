truncate table TPCH.SUPPLIER
truncate table TPCH.CUSTOMER
truncate table TPCH.NATION
truncate table TPCH.REGION
